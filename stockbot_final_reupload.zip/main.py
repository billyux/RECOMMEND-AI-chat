import os
os.system("streamlit run streamlit_app.py")