[실행 안내]

1. Python 3.9 이상 설치
2. 아래 명령어 실행:
   pip install -r requirements.txt
   python main.py