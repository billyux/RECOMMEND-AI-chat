import streamlit as st

st.set_page_config(page_title="주식 추천 챗봇", layout="centered")
st.title("📊 미래에셋 리포트 기반 종목 추천 챗봇")
st.write("HyperCLOVA X와 LangChain을 기반으로 종목을 추천합니다.")